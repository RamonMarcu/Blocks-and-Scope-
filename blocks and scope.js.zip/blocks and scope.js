//main js.

const city = 'New York City';

const logCitySkyline = () => {
  let skyscraper = 'Empire State Building';
   return 'The stars over the ' + skyscraper + ' in ' + city;
};

console.log(logCitySkyline());

// The stars over the Empire State Building in New York City